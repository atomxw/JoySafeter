// Vulnerable JavaScript - For Testing Whitebox Scanner

const express = require('express');
const app = express();

// Vulnerability 1: SQL Injection (Node.js style)
app.get('/user', (req, res) => {
    const userId = req.query.id;
    // VULNERABLE: String concatenation in SQL
    const query = "SELECT * FROM users WHERE id = '" + userId + "'";
    db.query(query, (err, result) => {
        res.json(result);
    });
});

// Vulnerability 2: XSS
app.get('/search', (req, res) => {
    const term = req.query.q;
    // VULNERABLE: Direct HTML insertion
    res.send(`<h1>Search results for: ${term}</h1>`);
});

// Vulnerability 3: Command Injection
const { exec } = require('child_process');

app.get('/run', (req, res) => {
    const cmd = req.query.command;
    // VULNERABLE: Unsanitized command execution
    exec(cmd, (error, stdout, stderr) => {
        res.send(stdout);
    });
});

// Vulnerability 4: Hardcoded Secrets
const API_KEY = "AKIAIOSFODNN7EXAMPLE";  // VULNERABLE
const SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";  // VULNERABLE

// Vulnerability 5: Prototype Pollution
app.post('/merge', (req, res) => {
    const obj = {};
    // VULNERABLE: Unvalidated merge
    Object.assign(obj, req.body);
    res.json(obj);
});

// Vulnerability 6: Open Redirect
app.get('/redirect', (req, res) => {
    const url = req.query.url;
    // VULNERABLE: No URL validation
    res.redirect(url);
});

// Vulnerability 7: Path Traversal
const fs = require('fs');

app.get('/download', (req, res) => {
    const file = req.query.file;
    // VULNERABLE: No path sanitization
    res.sendFile('/uploads/' + file);
});

app.listen(3001);
