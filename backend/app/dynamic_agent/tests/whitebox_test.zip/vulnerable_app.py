"""
Vulnerable Flask Application - For Testing Whitebox Scanner

This file contains intentional security vulnerabilities for testing purposes.
DO NOT use in production!
"""

import os
import subprocess
from flask import Flask, request, render_template_string

app = Flask(__name__)


# Vulnerability 1: SQL Injection
def get_user(user_id):
    """SQL Injection vulnerability - user input directly in query."""
    import sqlite3
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    # VULNERABLE: Direct string concatenation
    query = "SELECT * FROM users WHERE id = '" + user_id + "'"
    cursor.execute(query)
    return cursor.fetchone()


# Vulnerability 2: Command Injection
@app.route('/ping')
def ping():
    """Command injection vulnerability."""
    host = request.args.get('host', 'localhost')
    # VULNERABLE: User input directly passed to shell command
    result = subprocess.check_output(f"ping -c 1 {host}", shell=True)
    return result


# Vulnerability 3: XSS (Cross-Site Scripting)
@app.route('/greet')
def greet():
    """Reflected XSS vulnerability."""
    name = request.args.get('name', 'Guest')
    # VULNERABLE: User input directly rendered without escaping
    return render_template_string(f"<h1>Hello, {name}!</h1>")


# Vulnerability 4: Path Traversal
@app.route('/file')
def read_file():
    """Path traversal vulnerability."""
    filename = request.args.get('name', 'default.txt')
    # VULNERABLE: No path validation
    with open(f"/var/www/files/{filename}", 'r') as f:
        return f.read()


# Vulnerability 5: Hardcoded Secret
API_SECRET = "sk_live_1234567890abcdef"  # VULNERABLE: Hardcoded secret
DATABASE_PASSWORD = "admin123"  # VULNERABLE: Hardcoded password


# Vulnerability 6: Insecure Deserialization
import pickle

@app.route('/load')
def load_data():
    """Insecure deserialization vulnerability."""
    data = request.args.get('data')
    # VULNERABLE: Unpickling untrusted data
    obj = pickle.loads(bytes.fromhex(data))
    return str(obj)


# Vulnerability 7: SSRF
import requests as http_requests

@app.route('/fetch')
def fetch_url():
    """Server-Side Request Forgery vulnerability."""
    url = request.args.get('url')
    # VULNERABLE: No URL validation
    response = http_requests.get(url)
    return response.text


if __name__ == '__main__':
    app.run(debug=True)  # VULNERABLE: Debug mode in production
